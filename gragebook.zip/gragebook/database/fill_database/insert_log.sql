
-- Inserare log_type.
insert into log_type(`log_type`) values("updated profile");
insert into log_type(`log_type`) values("created user");

select * from log_type;

-- Inserare log.
-- update pe teacher 