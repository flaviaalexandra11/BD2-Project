# Proiect Baze de date 2 - Catalog electornic

# Baza de date
Din folder-ul cu *docker-compose.yml* se pornește din terminal: `docker-compose up`.

Pentru oprire: `docker-compose down`.

Pentru oprire cu ștergerea informațiilor create de către backend / neinițializate la pornire: `docker-compose down -v`.

# Backend 
Se instaleaza pachetele din requirements.txt: `pip3 install -r requirements.txt`

Se ruleaza script-ul `app.py`.

# Frontend
Se deschide `index.html`.

### Student: Popescu Flavia-Alexandra 343C3

 
